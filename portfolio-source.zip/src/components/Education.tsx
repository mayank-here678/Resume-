import  { motion } from 'framer-motion';
import { BookOpen, Calendar, MapPin } from 'lucide-react';

const educationData = [
  {
    degree: "BCA (Pursuing)",
    institution: "Banarsidas Chandiwala Institute of Information Technology, GGSIPU",
    duration: "2023 - 2026",
    location: "Delhi"
  },
  {
    degree: "Intermediate",
    institution: "DAV Public School",
    duration: "2022 - 2023",
    location: "Delhi"
  },
  {
    degree: "Matriculation",
    institution: "DAV Public School",
    duration: "2020 - 2021",
    location: "Delhi"
  }
];

export default function Education() {
  return (
    <section id="education" className="py-20 bg-secondary-900">
      <div className="container mx-auto px-4 md:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="section-title">Education</h2>
          <p className="max-w-3xl mx-auto text-lg text-secondary-300">
            My academic journey that has shaped my skills
          </p>
        </motion.div>

        <div className="max-w-4xl mx-auto">
          <div className="flex flex-col space-y-8">
            {educationData.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="card hover:border-primary-500/30 relative"
              >
                {/* Timeline connector */}
                {index < educationData.length - 1 && (
                  <div className="absolute top-full left-8 w-0.5 h-8 bg-primary-500/30 z-0"></div>
                )}
                
                <div className="flex flex-col md:flex-row gap-4 items-start">
                  <div className="p-3 bg-primary-500/10 rounded-full ring-2 ring-primary-500/20 z-10">
                    <BookOpen className="h-6 w-6 text-primary-400" />
                  </div>
                  
                  <div className="flex-1">
                    <h3 className="text-xl font-semibold text-primary-300 mb-1">{item.degree}</h3>
                    <p className="text-lg text-secondary-300 mb-3">{item.institution}</p>
                    
                    <div className="flex flex-wrap gap-4 text-secondary-400">
                      <div className="flex items-center text-sm">
                        <Calendar className="h-4 w-4 mr-2 text-primary-500/70" />
                        <span>{item.duration}</span>
                      </div>
                      <div className="flex items-center text-sm">
                        <MapPin className="h-4 w-4 mr-2 text-primary-500/70" />
                        <span>{item.location}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
 