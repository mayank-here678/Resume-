import  { motion } from 'framer-motion';
import { Award, Code, FileText } from 'lucide-react';
import { useState } from 'react';

const certificates = [
  {
    title: "CERTIFICATE OF COMPLETION",
    icon: <Code className="h-6 w-6" />,
    description: "Delta Full Stack Web Development course from Apna College.",
    image: "https://imagedelivery.net/FIZL8110j4px64kO6qJxWA/ff867113-aafd-496f-c907-643847f4db00/public"
  },
  {
    title: "CERTIFICATE OF INTERNSHIP",
    icon: <Award className="h-6 w-6" />,
    description: "Content Writing Internship at InAmigos Foundation.",
    image: "https://imagedelivery.net/FIZL8110j4px64kO6qJxWA/9da273ad-eff5-4214-0594-16fea3c0ba00/public"
  },
  {
    title: "CERTIFICATE OF APPRECIATION",
    icon: <FileText className="h-6 w-6" />,
    description: "Recognition for excellence and contributions to projects.",
    image: "https://imagedelivery.net/FIZL8110j4px64kO6qJxWA/31d1906e-e422-443f-b62d-2f803924f600/public"
  }
];

export default function Certificates() {
  const [selectedCert, setSelectedCert] = useState<null | {
    title: string;
    image: string;
  }>(null);

  return (
    <section id="certificates" className="py-20 bg-secondary-900">
      <div className="container mx-auto px-4 md:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="section-title">Certificates</h2>
          <p className="max-w-3xl mx-auto text-lg text-secondary-300">
            Achievements and credentials that validate my skills
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {certificates.map((cert, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="card hover:border-primary-500/30 hover:shadow-lg cursor-pointer transition-all"
              onClick={() => setSelectedCert({ title: cert.title, image: cert.image })}
            >
              <div className="flex flex-col items-center text-center">
                <div className="p-3 bg-primary-500/10 rounded-full mb-4 text-primary-400">
                  {cert.icon}
                </div>
                <h3 className="text-lg font-semibold text-primary-300 mb-2">{cert.title}</h3>
                <p className="text-secondary-400 text-sm">{cert.description}</p>
                <button 
                  className="mt-4 text-primary-400 text-sm font-medium hover:text-primary-300 transition-colors"
                >
                  View Certificate
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {selectedCert && (
        <div 
          className="fixed inset-0 bg-secondary-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          onClick={() => setSelectedCert(null)}
        >
          <div 
            className="bg-secondary-900 rounded-lg p-4 max-w-3xl w-full"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium text-primary-300">{selectedCert.title}</h3>
              <button 
                className="text-secondary-400 hover:text-secondary-200"
                onClick={() => setSelectedCert(null)}
              >
                &times;
              </button>
            </div>
            <div className="bg-secondary-800 rounded-lg overflow-hidden">
              <img 
                src={selectedCert.image} 
                alt={selectedCert.title} 
                className="w-full h-auto"
              />
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
 