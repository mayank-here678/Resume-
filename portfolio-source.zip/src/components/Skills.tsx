import  { motion } from 'framer-motion';

const skillGroups = [
  {
    category: "Front-End",
    skills: [
      { name: "HTML", icon: "⚡", proficiency: 90 },
      { name: "CSS", icon: "🎨", proficiency: 85 },
      { name: "JavaScript", icon: "👨‍💻", proficiency: 80 },
    ]
  },
  {
    category: "Back-End",
    skills: [
      { name: "Python", icon: "🐍", proficiency: 75 },
      { name: "SQL", icon: "🗄️", proficiency: 70 },
    ]
  },
  {
    category: "Other",
    skills: [
      { name: "C++", icon: "⚙️", proficiency: 75 },
      { name: "Git", icon: "📝", proficiency: 65 },
      { name: "Problem Solving", icon: "🧩", proficiency: 85 },
    ]
  },
  {
    category: "Soft Skills",
    skills: [
      { name: "Communication", icon: "🗣️", proficiency: 90 },
      { name: "Leadership", icon: "🚀", proficiency: 85 },
      { name: "Adaptability", icon: "🔄", proficiency: 90 },
      { name: "Problem Solving", icon: "🧠", proficiency: 95 }
    ]
  }
];

export default function Skills() {
  return (
    <section id="skills" className="py-20 bg-secondary-900">
      <div className="container mx-auto px-4 md:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="section-title">My Skills</h2>
          <p className="max-w-3xl mx-auto text-lg text-secondary-300">
            Technologies and tools I work with
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
          {skillGroups.map((group, groupIndex) => (
            <motion.div
              key={groupIndex}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: groupIndex * 0.1 }}
              className="card hover:border-primary-500/30"
            >
              <h3 className="text-xl font-semibold text-primary-400 mb-4">{group.category}</h3>
              <div className="space-y-5">
                {group.skills.map((skill, skillIndex) => (
                  <div key={skillIndex} className="space-y-2">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center space-x-2">
                        <span>{skill.icon}</span>
                        <span className="font-medium text-secondary-200">{skill.name}</span>
                      </div>
                      <span className="text-xs text-secondary-400">{skill.proficiency}%</span>
                    </div>
                    <div className="h-2 bg-secondary-800 rounded-full overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        whileInView={{ width: `${skill.proficiency}%` }}
                        viewport={{ once: true }}
                        transition={{ duration: 1, delay: 0.1 + skillIndex * 0.1 }}
                        className="h-full bg-gradient-to-r from-primary-600 to-primary-400 rounded-full"
                      ></motion.div>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
 