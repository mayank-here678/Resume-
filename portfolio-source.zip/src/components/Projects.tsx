import  { motion } from 'framer-motion';
import { ExternalLink, Github, Code } from 'lucide-react';

const projects = [
  {
    title: "Personal Portfolio",
    description: "A responsive developer portfolio showcasing skills and projects",
    technologies: ["React", "TailwindCSS", "Framer Motion"],
    image: "https://images.unsplash.com/photo-1555099962-4199c345e5dd?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    demoLink: "#",
    codeLink: "#"
  },
  {
    title: "E-commerce Platform",
    description: "A full-featured online shopping platform with cart functionality",
    technologies: ["JavaScript", "Node.js", "Express", "MongoDB"],
    image: "https://images.unsplash.com/photo-1556742393-d75f468bfcb0?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    demoLink: "#",
    codeLink: "#"
  },
  {
    title: "Weather Dashboard",
    description: "Real-time weather information app with location search",
    technologies: ["HTML", "CSS", "JavaScript", "Weather API"],
    image: "https://images.unsplash.com/photo-1534088568595-a066f410bcda?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    demoLink: "#",
    codeLink: "#"
  }
];

export default function Projects() {
  return (
    <section id="projects" className="py-20 bg-secondary-950">
      <div className="container mx-auto px-4 md:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="section-title">My Projects</h2>
          <p className="max-w-3xl mx-auto text-lg text-secondary-300">
            Check out some of my recent work
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="card group overflow-hidden"
            >
              <div className="relative overflow-hidden rounded-lg mb-4 h-48">
                <img 
                  src={project.image} 
                  alt={project.title} 
                  className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-secondary-900/70 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-3">
                  <a href={project.demoLink} className="p-2 rounded-full bg-primary-500 text-white hover:bg-primary-600 transition-colors">
                    <ExternalLink className="h-5 w-5" />
                  </a>
                  <a href={project.codeLink} className="p-2 rounded-full bg-secondary-800 text-white hover:bg-secondary-700 transition-colors">
                    <Github className="h-5 w-5" />
                  </a>
                </div>
              </div>
              
              <h3 className="text-lg font-semibold text-primary-300 mb-2 group-hover:text-primary-400 transition-colors">
                {project.title}
              </h3>
              
              <p className="text-secondary-400 text-sm mb-3">
                {project.description}
              </p>
              
              <div className="flex flex-wrap gap-2 mb-4">
                {project.technologies.map((tech, techIndex) => (
                  <span 
                    key={techIndex} 
                    className="text-xs px-2 py-1 rounded-full bg-secondary-800 text-secondary-300 border border-secondary-700"
                  >
                    {tech}
                  </span>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
 