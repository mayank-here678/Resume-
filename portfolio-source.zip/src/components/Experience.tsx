import  { motion } from 'framer-motion';
import { Briefcase, Calendar, MapPin, ChevronRight, Award } from 'lucide-react';

export default function Experience() {
  return (
    <section id="experience" className="py-20 bg-secondary-950">
      <div className="container mx-auto px-4 md:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="section-title">Experience</h2>
          <p className="max-w-3xl mx-auto text-lg text-secondary-300">
            My professional journey and work experience
          </p>
        </motion.div>

        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="card hover:border-primary-500/30 border-l-4 border-l-primary-500"
          >
            <div className="flex flex-col md:flex-row gap-6">
              <div className="md:w-1/4">
                <div className="p-3 bg-primary-500/10 rounded-full inline-flex mb-3">
                  <Briefcase className="h-6 w-6 text-primary-400" />
                </div>
                <h4 className="text-primary-400 font-medium mb-2">InAmigos Foundation</h4>
                <div className="flex items-center text-secondary-400 mb-2 text-sm">
                  <Calendar className="h-4 w-4 mr-2" />
                  <span>April 15 - 28, 2025</span>
                </div>
                <div className="flex items-center text-secondary-400 text-sm">
                  <MapPin className="h-4 w-4 mr-2" />
                  <span>Remote</span>
                </div>
              </div>
              
              <div className="md:w-3/4">
                <h3 className="text-xl font-semibold text-primary-300 mb-3">Content Writing Intern</h3>
                <p className="text-secondary-300 mb-4">
                  Successfully completed a short-term internship focused on content writing, contributing impactful and engaging content for various initiatives.
                </p>
                
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <ChevronRight className="h-5 w-5 text-primary-500 mt-0.5 flex-shrink-0" />
                    <span className="text-secondary-300">Created engaging blog content for the foundation's website</span>
                  </li>
                  <li className="flex items-start">
                    <ChevronRight className="h-5 w-5 text-primary-500 mt-0.5 flex-shrink-0" />
                    <span className="text-secondary-300">Developed social media copy to increase audience engagement</span>
                  </li>
                  <li className="flex items-start">
                    <ChevronRight className="h-5 w-5 text-primary-500 mt-0.5 flex-shrink-0" />
                    <span className="text-secondary-300">Recognized for dedication, responsibility, and valuable contributions by the HR department</span>
                  </li>
                </ul>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="mt-8 flex justify-center"
          >
            <div className="card p-6 inline-flex items-center gap-3">
              <div className="p-3 bg-primary-500/10 rounded-full">
                <Award className="h-6 w-6 text-primary-400" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-primary-300">
                  View my certificates in the next section
                </h3>
                <p className="text-secondary-400 text-sm">
                  Check out the certificates I've earned along my journey
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
 