import  { motion } from "framer-motion";

import  { motion } from 'framer-motion';

export default function Languages() {
  return (
    <section id="languages" className="py-20 bg-secondary-950">
      <div className="container mx-auto px-4 md:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
 
        >
          <h2 className="text-3xl font-bold tracking-tight text-white sm:text-4xl mb-4">
            Languages
          </h2>
          <div className="w-16 h-1 mx-auto bg-primary-500 rounded-full mb-6"></div>
        </motion.div>
        
        <div className="max-w-3xl mx-auto bg-secondary-900 rounded-xl p-6 shadow-xl border border-secondary-800">
          <div className="space-y-4">
            <div className="flex items-center space-x-3">
              <span className="text-xl">🗣</span>
              <div>
                <span className="font-semibold text-white">Hindi</span>
                <p className="text-secondary-400 text-sm">Full Professional Proficiency</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-3">
              <span className="text-xl">🗣</span>
              <div>
                <span className="font-semibold text-white">English</span>
                <p className="text-secondary-400 text-sm">Full Professional Proficiency</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
 