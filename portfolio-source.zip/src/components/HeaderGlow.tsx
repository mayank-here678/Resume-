import  { motion } from 'framer-motion';

export default function HeaderGlow() {
  return (
    <div className="absolute inset-x-0 top-0 h-40 pointer-events-none overflow-hidden">
      <div className="absolute inset-0 z-[-1] opacity-30">
        <motion.div
          className="absolute -inset-[10px] rounded-full bg-primary-600/30 blur-3xl"
          animate={{
            scale: [1, 1.1, 1],
            opacity: [0.3, 0.5, 0.3],
          }}
          transition={{
            duration: 5,
            repeat: Infinity,
            repeatType: "reverse",
          }}
        />
        <motion.div
          className="absolute top-1/3 -right-14 h-72 w-72 rounded-full bg-secondary-400/20 blur-3xl"
          animate={{
            scale: [1, 1.2, 1],
            x: [0, -20, 0],
            opacity: [0.2, 0.4, 0.2],
          }}
          transition={{
            duration: 7,
            repeat: Infinity,
            repeatType: "reverse",
          }}
        />
        <motion.div
          className="absolute -top-10 -left-20 h-72 w-72 rounded-full bg-primary-700/20 blur-3xl"
          animate={{
            scale: [1, 1.3, 1],
            x: [0, 30, 0],
            opacity: [0.3, 0.2, 0.3],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            repeatType: "reverse",
          }}
        />
      </div>
    </div>
  );
}
 