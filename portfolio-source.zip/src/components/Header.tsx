import  { useState, useEffect } from 'react';
import { Link as ScrollLink } from 'react-scroll';
import { Menu, X } from 'lucide-react';

const navItems = [
  { name: 'Home', target: 'hero' },
  { name: 'About', target: 'about' },
  { name: 'Education', target: 'education' },
  { name: 'Skills', target: 'skills' },
  { name: 'Experience', target: 'experience' },
  { name: 'Certificates', target: 'certificates' },
  { name: 'Contact', target: 'contact' },
];

export default function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [activeLink, setActiveLink] = useState('hero');

  // Handle scroll to determine active section and header style
  useEffect(() => {
    const handleScroll = () => {
      // Update header background
      setIsScrolled(window.scrollY > 50);
      
      // Update active section
      const sections = navItems.map(item => item.target);
      for (let i = sections.length - 1; i >= 0; i--) {
        const section = document.getElementById(sections[i]);
        if (section) {
          const rect = section.getBoundingClientRect();
          if (rect.top <= 100) {
            setActiveLink(sections[i]);
            break;
          }
        }
      }
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header 
      className={`fixed w-full top-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-secondary-900/90 backdrop-blur-sm py-3 shadow-md' : 'bg-transparent py-5'
      }`}
    >
      <div className="container mx-auto px-4 md:px-6">
        <nav className="flex items-center justify-between">
          <ScrollLink
            to="hero"
            spy={true}
            smooth={true}
            offset={-70}
            duration={500}
            className="text-2xl font-bold text-white cursor-pointer"
            onClick={() => setActiveLink('hero')}
          >
            <span className="text-primary-400">M</span>ayank
          </ScrollLink>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-1">
            {navItems.map((item) => (
              <ScrollLink
                key={item.target}
                to={item.target}
                spy={true}
                smooth={true}
                offset={-70}
                duration={500}
                className={`px-3 py-2 rounded-md text-sm font-medium cursor-pointer transition-colors ${
                  activeLink === item.target
                    ? 'text-primary-400'
                    : 'text-secondary-300 hover:text-primary-300'
                }`}
                onClick={() => setActiveLink(item.target)}
              >
                {item.name}
              </ScrollLink>
            ))}
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2 rounded-md text-secondary-300 hover:text-white focus:outline-none"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X /> : <Menu />}
          </button>
        </nav>
      </div>

      {/* Mobile Menu */}
      <div
        className={`md:hidden transition-all duration-300 ease-in-out ${
          isMobileMenuOpen
            ? 'max-h-[400px] opacity-100 visible py-4'
            : 'max-h-0 opacity-0 invisible py-0'
        } overflow-hidden bg-secondary-900/95 backdrop-blur-sm`}
      >
        <div className="container mx-auto px-4 space-y-1">
          {navItems.map((item) => (
            <ScrollLink
              key={item.target}
              to={item.target}
              spy={true}
              smooth={true}
              offset={-70}
              duration={500}
              className={`block px-4 py-2 rounded-md text-base font-medium cursor-pointer ${
                activeLink === item.target
                  ? 'bg-secondary-800 text-primary-400'
                  : 'text-secondary-300 hover:bg-secondary-800 hover:text-primary-300'
              }`}
              onClick={() => {
                setActiveLink(item.target);
                setIsMobileMenuOpen(false);
              }}
            >
              {item.name}
            </ScrollLink>
          ))}
        </div>
      </div>
    </header>
  );
}
 