import  { motion } from 'framer-motion';
import { Terminal, User, Award, Code } from 'lucide-react';

export default function About() {
  return (
    <section id="about" className="py-20 bg-secondary-950">
      <div className="container mx-auto px-4 md:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="section-title">About Me</h2>
          <p className="max-w-3xl mx-auto text-lg text-secondary-300">
            I'm a dedicated BCA student with a passion for software development
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="order-2 lg:order-1"
          >
            <div className="terminal-window">
              <div className="terminal-header">
                <div className="terminal-circle bg-red-500"></div>
                <div className="terminal-circle bg-yellow-500"></div>
                <div className="terminal-circle bg-green-500"></div>
                <span className="ml-2 text-xs text-secondary-400">about.js</span>
              </div>
              <div className="terminal-content bg-code-bg text-code-text">
                <code>
                  <span className="code-line">
                    <span className="code-keyword">const</span> <span className="code-variable">developer</span> = {"{"}
                  </span>
                  <span className="code-line pl-4">
                    <span className="code-variable">name</span>: <span className="code-string">"Mayank Mathur"</span>,
                  </span>
                  <span className="code-line pl-4">
                    <span className="code-variable">role</span>: <span className="code-string">"Developer & Problem Solver"</span>,
                  </span>
                  <span className="code-line pl-4">
                    <span className="code-variable">education</span>: <span className="code-string">"BCA at BCIT, GGSIPU"</span>,
                  </span>
                  <span className="code-line pl-4">
                    <span className="code-variable">interests</span>: [<span className="code-string">"Web Development"</span>, <span className="code-string">"Programming"</span>, <span className="code-string">"Tech"</span>],
                  </span>
                  <span className="code-line pl-4">
                    <span className="code-function">getBio</span>: <span className="code-keyword">function</span>() {"{"}
                  </span>
                  <span className="code-line pl-8">
                    <span className="code-keyword">return</span> <span className="code-string">"Dedicated developer focused on creating clean,</span>
                  </span>
                  <span className="code-line pl-8">
                    <span className="code-string">efficient code and innovative digital solutions."</span>;
                  </span>
                  <span className="code-line pl-4">
                    {"}"}
                  </span>
                  <span className="code-line">
                    {"}"};
                  </span>
                  <span className="code-line mt-2">
                    <span className="code-comment">// Output</span>
                  </span>
                  <span className="code-line">
                    <span className="code-function">console.log</span>(<span className="code-variable">developer</span>.<span className="code-function">getBio</span>());
                  </span>
                </code>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="order-1 lg:order-2"
          >
            <h3 className="text-2xl font-semibold text-primary-300 mb-4">
              Who I Am
            </h3>
            <p className="text-secondary-300 mb-6">
              A highly motivated and detail-oriented BCA student at
              Banarsidas Chandiwala Institute of Information
              Technology, affiliated with GGSIPU, with a strong interest
              in software development and digital content creation.
            </p>
            <p className="text-secondary-300 mb-6">
              Successfully completed a Content Writing Internship at
              InAmigos Foundation and earned recognition for
              commitment and quality contributions. Also completed
              the Delta Full Stack Web Development course from Apna
              College, building a solid foundation in front-end and
              back-end technologies. Eager to apply academic
              knowledge and internship experience to real-world tech
              challenges while continuously learning and growing.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
              {[
                {
                  icon: <Terminal className="h-6 w-6 text-primary-400" />,
                  title: "Clean Code",
                  description: "Writing maintainable, efficient code"
                },
                {
                  icon: <User className="h-6 w-6 text-primary-400" />,
                  title: "Problem Solver",
                  description: "Analytical approach to challenges"
                },
                {
                  icon: <Code className="h-6 w-6 text-primary-400" />,
                  title: "Tech Enthusiast",
                  description: "Always learning new technologies"
                }
              ].map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: index * 0.1 }}
                  className="card hover:border-primary-500/30 hover:shadow-primary-900/5"
                >
                  <div className="flex flex-col items-center text-center">
                    <div className="mb-3 p-2 bg-secondary-800 rounded-full">
                      {item.icon}
                    </div>
                    <h3 className="text-lg font-semibold text-primary-300 mb-1">{item.title}</h3>
                    <p className="text-secondary-400 text-sm">{item.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
 