import  { GitHub, Linkedin, Mail, MapPin, Phone } from 'lucide-react';
import { motion } from 'framer-motion';
import { useState } from 'react';

export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });
  const [formStatus, setFormStatus] = useState<{type: string; message: string} | null>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulating form submission
    setFormStatus({type: 'success', message: 'Thank you for your message! I will get back to you soon.'});
    
    // Reset form
    setFormData({
      name: '',
      email: '',
      message: ''
    });
    
    // Clear status after 5 seconds
    setTimeout(() => {
      setFormStatus(null);
    }, 5000);
  };

  return (
    <section id="contact" className="py-20 bg-secondary-900">
      <div className="container mx-auto px-4 md:px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl font-bold mb-4 inline-block">
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-primary-400 to-primary-600">
              Get In Touch
            </span>
          </h2>
          <div className="w-16 h-1 bg-primary-500 mx-auto rounded-full mb-6"></div>
          <p className="text-lg text-secondary-300 max-w-2xl mx-auto">
            I'm always open to new opportunities and collaborations. 
            Feel free to reach out through the form below or my contact details.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 max-w-6xl mx-auto">
          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="bg-secondary-800 rounded-lg p-6 shadow-lg"
          >
            <h3 className="text-xl font-semibold mb-6 text-primary-400">Send Me a Message</h3>
            
            {formStatus && (
              <div className={`mb-6 p-4 rounded ${formStatus.type === 'success' ? 'bg-green-900/30 text-green-400' : 'bg-red-900/30 text-red-400'}`}>
                {formStatus.message}
              </div>
            )}
            
            <form onSubmit={handleSubmit}>
              <div className="mb-4">
                <label htmlFor="name" className="block text-sm font-medium text-secondary-300 mb-1">Name</label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-2 rounded-md bg-secondary-700 border border-secondary-600 focus:border-primary-500 focus:ring-1 focus:ring-primary-500 outline-none transition-colors"
                  placeholder="Your name"
                />
              </div>
              
              <div className="mb-4">
                <label htmlFor="email" className="block text-sm font-medium text-secondary-300 mb-1">Email</label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-2 rounded-md bg-secondary-700 border border-secondary-600 focus:border-primary-500 focus:ring-1 focus:ring-primary-500 outline-none transition-colors"
                  placeholder="Your email"
                />
              </div>
              
              <div className="mb-6">
                <label htmlFor="message" className="block text-sm font-medium text-secondary-300 mb-1">Message</label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  required
                  rows={5}
                  className="w-full px-4 py-2 rounded-md bg-secondary-700 border border-secondary-600 focus:border-primary-500 focus:ring-1 focus:ring-primary-500 outline-none transition-colors resize-none"
                  placeholder="Your message"
                ></textarea>
              </div>
              
              <button
                type="submit"
                className="w-full py-3 px-6 bg-primary-600 hover:bg-primary-700 text-white font-medium rounded-md transition-colors focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2 focus:ring-offset-secondary-800"
              >
                Send Message
              </button>
            </form>
          </motion.div>
          
          {/* Contact Information */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            <h3 className="text-xl font-semibold mb-6 text-primary-400">Contact Information</h3>
            
            <div className="space-y-6">
              <div className="flex items-start space-x-4">
                <div className="bg-secondary-800 p-3 rounded-lg">
                  <Mail className="text-primary-400" size={24} />
                </div>
                <div>
                  <h4 className="font-medium text-white">Email</h4>
                  <a 
                    href="mailto:mayankmathur1255@gmail.com" 
                    className="text-secondary-300 hover:text-primary-400 transition-colors"
                  >
                    mayankmathur1255@gmail.com
                  </a>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="bg-secondary-800 p-3 rounded-lg">
                  <Phone className="text-primary-400" size={24} />
                </div>
                <div>
                  <h4 className="font-medium text-white">Phone</h4>
                  <a 
                    href="tel:9212551255" 
                    className="text-secondary-300 hover:text-primary-400 transition-colors"
                  >
                    +91 9212551255
                  </a>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="bg-secondary-800 p-3 rounded-lg">
                  <MapPin className="text-primary-400" size={24} />
                </div>
                <div>
                  <h4 className="font-medium text-white">Location</h4>
                  <a 
                    href="https://maps.app.goo.gl/9Eg2RZG1asYcoCbw5?g_st=aw" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-secondary-300 hover:text-primary-400 transition-colors"
                  >
                    View on Google Maps
                  </a>
                </div>
              </div>
              
              <div className="pt-8 border-t border-secondary-700">
                <h4 className="font-medium text-white mb-4">Connect with me</h4>
                <div className="flex space-x-4">
                  <a 
                    href="https://www.linkedin.com/in/mayank-mathur-827507343?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="bg-secondary-800 p-3 rounded-lg hover:bg-secondary-700 transition-colors text-primary-400 hover:text-primary-300"
                    aria-label="LinkedIn Profile"
                  >
                    <Linkedin size={24} />
                  </a>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
        
        <div className="mt-16 border-t border-secondary-800 pt-8 text-center">
          <p className="text-sm text-secondary-400">
            © {new Date().getFullYear()} Mayank Mathur. All rights reserved.
          </p>
        </div>
      </div>
    </section>
  );
}
 