import  { motion } from 'framer-motion';
import About from './components/About';
import Certificates from './components/Certificates';
import Contact from './components/Contact';
import Education from './components/Education';
import Experience from './components/Experience';
import Header from './components/Header';
import HeaderGlow from './components/HeaderGlow';
import Hero from './components/Hero';
import Skills from './components/Skills';

function App() {
  return (
    <div className="bg-secondary-950 text-white min-h-screen">
      <HeaderGlow />
      <Header />
      <motion.main 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <Hero />
        <About />
        <Education />
        <Skills />
        <Experience />
        <Certificates />
        <Contact />
      </motion.main>
    </div>
  );
}

export default App;
 